#include "game.h"

int main(int argc, char* argv[]) {
    Game app(argc, argv);
    return app.exec();
}
